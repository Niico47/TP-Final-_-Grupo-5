public class HabitacionEnMantenimientoException extends Exception {
    public HabitacionEnMantenimientoException(String mensaje) {
        super(mensaje);
    }
}