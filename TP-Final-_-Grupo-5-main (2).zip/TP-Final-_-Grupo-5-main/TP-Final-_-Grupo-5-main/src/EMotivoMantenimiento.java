public enum EMotivoMantenimiento {
    LIMPIEZA,
    DESINFECCION,
    REPARACION,
    NINGUNO
}