public interface IServicioMantenimiento {
    void solicitarMantenimiento(String motivo);
    void finalizarMantenimiento();
    boolean estaEnMantenimiento();
}

